//
//  main.m
//  HJSDKDemo
//
//  Created by bx_zhen on 2019/11/12.
//  Copyright © 2019 CL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
