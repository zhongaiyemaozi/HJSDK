//
//  QKN5GameSDK.h
//  QKN5GameSDK
//
//  Created by xingming on 2017/1/13.
//  Copyright © 2017年 xingming. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QKN5GameSDK.
FOUNDATION_EXPORT double QuickH5GameSDKVersionNumber;

//! Project version string for QKN5GameSDK.
FOUNDATION_EXPORT const unsigned char QuickH5GameSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QKN5GameSDK/PublicHeader.h>
#import <QKN5GameSDK/QKN5GameHolder.h>


