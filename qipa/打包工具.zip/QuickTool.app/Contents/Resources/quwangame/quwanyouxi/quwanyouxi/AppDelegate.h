//
//  AppDelegate.h
//  quwanyouxi
//
//  Created by 0280106PC0119 on 2017/2/4.
//  Copyright © 2017年 quicksdk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) ViewController *viewController;

@end

