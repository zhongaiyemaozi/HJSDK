//
//  ViewController.m
//  quwanyouxi
//
//  Created by 0280106PC0119 on 2017/2/4.
//  Copyright © 2017年 quicksdk. All rights reserved.
//

#import "ViewController.h"
#import <QKN5GameSDK/QKN5GameSDK.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    QKN5GameHolder *holder = [QKN5GameHolder sharedInstance];
    [holder setDelegate:self];
    [holder setHolderRootViewCtr:self];
    [holder loadGameFromCfg];
    
    [self.view bringSubviewToFront:self.splashImage];
    
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    self.baseOrientations = infoDic[@"UISupportedInterfaceOrientations"];
    
    [self performSelector:@selector(splashHide) withObject:nil afterDelay:10];
}

- (void)h5gameDidLoaded
{
    [self splashHide];
}

-(void)splashHide
{
    [UIView animateWithDuration:0.5 animations:^{
        self.splashImage.alpha = 0;
    } completion:^(BOOL finished) {
        self.splashImage.hidden = YES;
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    BOOL landscapeLeft = [self.baseOrientations containsObject:@"UIInterfaceOrientationLandscapeLeft"];
    BOOL landscapeRight = [self.baseOrientations containsObject:@"UIInterfaceOrientationLandscapeRight"];
    BOOL portrait = [self.baseOrientations containsObject:@"UIInterfaceOrientationPortrait"];
    BOOL portraitUpsideDown = [self.baseOrientations containsObject:@"UIInterfaceOrientationPortraitUpsideDown"];
    UIInterfaceOrientationMask mask = 0;
    if (landscapeLeft)
        mask |= UIInterfaceOrientationMaskLandscapeLeft;
    if (landscapeRight)
        mask |= UIInterfaceOrientationMaskLandscapeRight;
    if (portrait)
        mask |= UIInterfaceOrientationMaskPortrait;
    if (portraitUpsideDown)
        mask |= UIInterfaceOrientationMaskPortraitUpsideDown;
    
    return mask;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    BOOL landscapeLeft = [self.baseOrientations containsObject:@"UIInterfaceOrientationLandscapeLeft"];
    BOOL landscapeRight = [self.baseOrientations containsObject:@"UIInterfaceOrientationLandscapeRight"];
    //BOOL portrait = [self.baseOrientations containsObject:@"UIInterfaceOrientationPortrait"];
    //BOOL portraitUpsideDown = [self.baseOrientations containsObject:@"UIInterfaceOrientationPortraitUpsideDown"];
    if (landscapeLeft || landscapeRight)
        return UIInterfaceOrientationLandscapeRight;
    else
        return UIInterfaceOrientationPortrait;
}

@end
