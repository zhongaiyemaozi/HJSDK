//
//  QKN5GameHolder.h
//  H5GameApp
//
//  Created by xingming on 2017/1/13.
//  Copyright © 2017年 xingming. All rights reserved.
//

#define H5ALL_SDK_VERSION @"1.0.9"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol QuickH5GameHolderDelegate <NSObject>
- (void)h5gameDidLoaded;
@end

@interface QKN5GameHolder : NSObject

+(instancetype)sharedInstance;
@property (nonatomic,strong) id<QuickH5GameHolderDelegate> delegate;
@property (nonatomic,strong) UIViewController *holderRootViewCtr;
@property (nonatomic,strong) NSString *gameUrlStr;
- (void)reloadGame;
- (void)loadGameFromCfg;

//callback
-(void)callbackEvent:(NSString *)jsonData;//回调web事件

//app事件
- (void)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
- (void)applicationWillResignActive:(UIApplication *)application;
- (void)applicationDidEnterBackground:(UIApplication *)application;

- (void)applicationWillEnterForeground:(UIApplication *)application;
- (void)applicationDidBecomeActive:(UIApplication *)application;
- (void)applicationWillTerminate:(UIApplication *)application;
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo;
- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(nullable UIWindow *)window;
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url;
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(id)annotation;
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options;
@end
