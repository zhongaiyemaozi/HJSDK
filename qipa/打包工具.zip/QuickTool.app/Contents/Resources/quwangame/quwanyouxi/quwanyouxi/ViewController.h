//
//  ViewController.h
//  quwanyouxi
//
//  Created by 0280106PC0119 on 2017/2/4.
//  Copyright © 2017年 quicksdk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QKN5GameSDK/QKN5GameHolder.h>

@interface ViewController : UIViewController<QuickH5GameHolderDelegate>

@property (nonatomic, strong) NSArray *baseOrientations;
@property (weak, nonatomic) IBOutlet UIImageView *splashImage;


@end

