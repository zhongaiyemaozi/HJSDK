# frozen_string_literal: true

module Nanaimo
  VERSION = '0.2.5'.freeze
end
