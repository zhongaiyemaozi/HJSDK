module I18n
  VERSION = "0.6.0"
end
