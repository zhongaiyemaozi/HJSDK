module Colored2
  VERSION = '3.1.2'
end
