
def addEntitlements(project, target, res) #只针对修改工程时候调用, 只针对第三方库和资源以及源文件，非系统库
    require File.dirname(__FILE__)+'/../lib/xcodeproj'

    begin
    proj = Xcodeproj::Project.open(project)

    group = proj.main_group.find_subpath(File.join('QuickSDK'), true)
    group.set_source_tree('SOURCE_ROOT')
    
    group.new_reference(res, 'SOURCE_ROOT')

    proj.save
    rescue =>e
        puts e.to_s
        logFileFolder = File.dirname(project)
        f=File.new(File.join(logFileFolder,"addEntitlements.txt"),"w+")
        f.puts(e.to_s)
        f.close
    end
end
    
addEntitlements(ARGV[0], ARGV[1], ARGV[2])
