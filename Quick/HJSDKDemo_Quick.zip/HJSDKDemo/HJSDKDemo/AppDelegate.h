//
//  AppDelegate.h
//  HJSDKDemo
//
//  Created by bx_zhen on 2019/11/12.
//  Copyright © 2019 CL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

