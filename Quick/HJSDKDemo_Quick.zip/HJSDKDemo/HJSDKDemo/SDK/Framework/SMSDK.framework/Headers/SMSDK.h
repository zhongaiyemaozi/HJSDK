//
//  SMSDK.h
//  SMSDK
//
//  Created by bx_zhen on 2019/11/4.
//  Copyright © 2019 CL. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SMSDK.
FOUNDATION_EXPORT double SMSDKVersionNumber;

//! Project version string for SMSDK.
FOUNDATION_EXPORT const unsigned char SMSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SMSDK/PublicHeader.h>


